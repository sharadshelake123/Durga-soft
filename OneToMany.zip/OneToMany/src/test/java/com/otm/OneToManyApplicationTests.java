package com.otm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
