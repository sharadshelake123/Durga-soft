package com.procedure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcedureappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcedureappApplication.class, args);
	}

}
