package com.micro.calldetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroCalldetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
