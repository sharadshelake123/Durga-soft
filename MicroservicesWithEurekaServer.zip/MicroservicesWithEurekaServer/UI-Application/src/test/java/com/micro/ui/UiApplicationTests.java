package com.micro.ui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiApplicationTests {

	@Test
	void contextLoads() {
	}

}
